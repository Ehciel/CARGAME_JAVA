import pygame
import sys
import random

pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
GRIDSIZE = 20
GRID_WIDTH = SCREEN_WIDTH // GRIDSIZE
GRID_HEIGHT = SCREEN_HEIGHT // GRIDSIZE
FPS = 10

# Colors
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Direction vectors
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# Set up display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Snake Game")
clock = pygame.time.Clock()

def draw_grid():
    for y in range(0, int(GRID_HEIGHT)):
        for x in range(0, int(GRID_WIDTH)):
            rect = pygame.Rect(x*GRIDSIZE, y*GRIDSIZE, GRIDSIZE, GRIDSIZE)
            pygame.draw.rect(screen, WHITE, rect, 1)

def draw_snake(snake):
    for segment in snake:
        rect = pygame.Rect(segment[0]*GRIDSIZE, segment[1]*GRIDSIZE, GRIDSIZE, GRIDSIZE)
        pygame.draw.rect(screen, GREEN, rect)

def draw_food(food):
    rect = pygame.Rect(food[0]*GRIDSIZE, food[1]*GRIDSIZE, GRIDSIZE, GRIDSIZE)
    pygame.draw.rect(screen, RED, rect)

def main():
    snake = [(GRID_WIDTH//2, GRID_HEIGHT//2)]
    direction = random.choice([UP, DOWN, LEFT, RIGHT])
    food = (random.randint(0, GRID_WIDTH-1), random.randint(0, GRID_HEIGHT-1))
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != DOWN:
                    direction = UP
                elif event.key == pygame.K_DOWN and direction != UP:
                    direction = DOWN
                elif event.key == pygame.K_LEFT and direction != RIGHT:
                    direction = LEFT
                elif event.key == pygame.K_RIGHT and direction != LEFT:
                    direction = RIGHT

        # Move the snake
        head_x, head_y = snake[0]
        new_head = (head_x + direction[0], head_y + direction[1])

        # Check for collisions
        if new_head in snake or new_head[0] < 0 or new_head[0] >= GRID_WIDTH or new_head[1] < 0 or new_head[1] >= GRID_HEIGHT:
            running = False  # Snake has collided with itself or the boundaries
        else:
            snake.insert(0, new_head)
            if new_head == food:
                food = (random.randint(0, GRID_WIDTH-1), random.randint(0, GRID_HEIGHT-1))
            else:
                snake.pop()

        # Render everything
        screen.fill((0, 0, 0))
        draw_grid()
        draw_snake(snake)
        draw_food(food)
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
0